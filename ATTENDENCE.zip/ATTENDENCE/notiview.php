<?php include("header.php");?>
<!DOCTYPE html>
<!--  NOTIFICATION VIEW
  *Author:ROHIT
-->
<html>
<head>
<title>Notification</title>
<style>
h1{
	color:tomato;
}
</style>
</head>
<body>
<h1>Your Notification</h1>
</body>
</html>
