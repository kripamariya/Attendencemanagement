<!DOCTYPE html>
<!-- HEADER PAGE
  *Author:BONY
-->
<html>
<head><title>
</title>
<link rel="stylesheet" type="text/css" href="style.css">
<style>

</style>
</head>
<body>
<div class="menubar">
<ul>
<li><a href="index.html">Home</a></li>


<li><a href="contact.php">Contact us</a></li>
<li><a href="login1.php">Logout</a></li>
</ul>
</div>
