<?php
/* STUDENT DASHBROAD
*Author:KRIPA
*/


include("header.php");?>

<div>
<img src="3.png" width="250px" height="150px" style="float:right;">
</div>
<div class="btd">
<form class="btf">

<button class="bt"><a href="attendence.php">VIEW ATTENDANCE</a></button><br><br>
<button class="bt"><a href="leave_application.php">APPLY LEAVE</a></button><br><br>
<button class="bt"><a href="notiview.php">Notification</a></button><br><br>
<button class="bt"><a href="messagebox.php">Messagebox</a></button><br><br>
</form>

</div>
<?php
include("footer.php");?>