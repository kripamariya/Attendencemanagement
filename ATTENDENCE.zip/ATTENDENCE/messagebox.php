<!DOCTYPE html>
<!--MESSAGE BOX
*Author:BONY
-->
<html>
<head>
<title>Leave Application</title>
<link rel="stylesheet"type="text/css"href="style.css">
</head>
<body class="t">


<div align="center">
<h1>Messagebox</h1><br><br>
<form name="register" action=""   method="POST" onsubmit="return validate()" class="lve">
<table class="lve-t">


<tr><td>To:	</td><td><select>	
<option  value="dp" class="a">CEO</option>
<option value="dp" class="a">Center Manager</option>
<option value="dp" class="a">Trainer</option>

</select>
<br><br></td></tr>

<tr><td>Subject:	</td><td>	<input type="text"  name="subject" class="a"><br><br></td></tr>
<tr><td>Message: </td><td><textarea name="content" placeholder="Write to your message." class="ab"></textarea ><br><br></td></tr>
<tr><td><input type="submit" value="Reset" name="submit" class="at"> </td>
<td><input type="submit" value="Send" name="submit" class="at"> </td>
</tr>
 </table></form></div>
 
 
 

 

