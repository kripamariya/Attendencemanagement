<!DOCTYPE html>
<!-- HEADER PAGE
  *Author:BONY
-->
<html>
<head><title>
</title>
<link rel="stylesheet" type="text/css" href="style.css">
<style>

</style>
</head>
<body>
<div class="menubar">
<ul>
<li><a href="dashboard.php">Home</a></li>
<li><a href="#">View</a>
   <div class="submenu">
     <ul>
     <li><a href="teach_view.php">Teacher</a></li>
     <li><a href="stu_view.php">Student</a></li>
	 <li><a href="parent_view.php">Parent</a></li>
     </ul>
   </div>
</li>

<li><a href="contact.php">Contact us</a></li>
<li><a href="login1.php">Login</a></li>
<li><a href="login1.php">Logout</a></li>
</ul>
</div>
