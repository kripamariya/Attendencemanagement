
<?php
/*  DASHBOARD 
  *Author:SURYA
*/

include("header1.php");?>

<div class="imge">
<img src="1.jpg">
</div>
<div class="btd">
<form class="btf">
<button class="bt"><a href="teacherregistration1.php">ADD STAFF</a></button><br><br>
<button class="bt"><a href="student registration.php">ADD STUDENT</a></button><br><br>
<button class="bt"><a href="parent registration.php">ADD PARENT</a></button><br><br>
<button class="bt"><a href="course.php">ADD COURSE</a></button><br><br>
<button class="bt"><a href="#">VIEW ATTENDANCE</button><br>
<button class="bt"><a href="view_req.php">VIEW LEAVE</button>
</form>

</div>
<?php
include("footer.php");?>


